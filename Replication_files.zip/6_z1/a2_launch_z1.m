% Jesus Fernandez-Villaverde, Samuel Hurtado and Galo Nuno (2018)
% Financial Frictions and the Wealth Distribution



cd z1_070
    a2_launch
cd ..


cd z1_068
    a2_launch
cd ..


cd z1_067
    a2_launch
cd ..


cd z1_073
    a2_launch
cd ..


cd z1_075
    a2_launch
cd ..


cd z1_077
    a2_launch
cd ..


cd z1_078
    a2_launch
cd ..


cd z1_080
    a2_launch
cd ..


cd z1_082
    a2_launch
cd ..


cd z1_083
    a2_launch
cd ..


cd z1_085
    a2_launch
cd ..


cd z1_087
    a2_launch
cd ..


cd z1_088
    a2_launch
cd ..


cd z1_090
    a2_launch
cd ..


cd z1_090_K3
    a2_launch
cd ..


cd z1_091
    a2_launch
cd ..


cd z1_092
    a2_launch
cd ..


cd z1_093
    a2_launch
cd ..


cd z1_094
    a2_launch
cd ..


cd z1_095
    a2_launch
cd ..


cd z1_096
    a2_launch
cd ..


cd z1_097
    a2_launch
cd ..



b1_plot_phase9
b2_plot_SSS
b3_plot_z1_distr
b5_IRF_072_097


close all

