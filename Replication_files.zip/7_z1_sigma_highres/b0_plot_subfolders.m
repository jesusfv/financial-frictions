% Jesus Fernandez-Villaverde, Samuel Hurtado and Galo Nuno (2018)
% Financial Frictions and the Wealth Distribution

cd sigma120
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


cd sigma160
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


cd sigma180
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


cd sigma200
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


cd sigma220
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


cd sigma240
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


cd sigma260
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


cd sigma280
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


cd sigma300
    b1_plot_phase9
    b2_plot_SSS
    b3_plot_z1_distr
cd ..


