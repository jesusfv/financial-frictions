% Jesus Fernandez-Villaverde, Samuel Hurtado and Galo Nuno (2018)
% Financial Frictions and the Wealth Distribution


cd z1_0695
    a2_launch
cd ..


cd z1_0745
    a2_launch
cd ..


cd z1_0795
    a2_launch
cd ..


cd z1_0845
    a2_launch
cd ..


cd z1_0895
    a2_launch
cd ..


cd z1_0945
    a2_launch
cd ..


close all

