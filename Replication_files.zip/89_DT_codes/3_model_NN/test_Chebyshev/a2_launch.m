% Jesus Fernandez-Villaverde, Samuel Hurtado and Galo Nuno (2018)
% Financial Frictions and the Wealth Distribution

clear
close all
clc

load '../z_FinalWorkspace.mat';
load '../z_FinalWorkspace_gsim.mat';
close all


b1_test_Chebyshev
b5_plot_PLM
