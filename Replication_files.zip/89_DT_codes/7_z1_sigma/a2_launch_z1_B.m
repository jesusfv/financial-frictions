% Jesus Fernandez-Villaverde, Samuel Hurtado and Galo Nuno (2018)
% Financial Frictions and the Wealth Distribution


cd sigma160
    a2_launch_z1
cd ..


cd sigma240
    a2_launch
cd ..


