% Jesus Fernandez-Villaverde, Samuel Hurtado and Galo Nuno (2018)
% Financial Frictions and the Wealth Distribution


cd z1_067
    a2_launch
cd ..


cd z1_077
    a2_launch
cd ..


cd z1_082
    a2_launch
cd ..


cd z1_087
    a2_launch
cd ..


cd z1_092
    a2_launch
cd ..


cd z1_097
    a2_launch
cd ..


b1_plot_phase9
b2_plot_SSS
b3_plot_z1_distr

close all

